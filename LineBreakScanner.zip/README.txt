12/15/2012

This is module that will recursively scan any folder on your server and analyze the kinds of line breaks in use.  It will provide you a report and allow you to open individual files to see which lines use carridge returns, line feeds, or both.

This code comes with no warranties, promises, or kittens.  In fact, it will probably format your hard drive.

Brad Wood
- brad@bradwood.com
- http://www.codersrevolution.com
